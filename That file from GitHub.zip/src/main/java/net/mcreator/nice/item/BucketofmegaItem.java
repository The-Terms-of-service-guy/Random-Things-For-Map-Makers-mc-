
package net.mcreator.nice.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BucketItem;

import net.mcreator.nice.init.NiceModFluids;

public class BucketofmegaItem extends BucketItem {
	public BucketofmegaItem() {
		super(NiceModFluids.BUCKETOFMEGA, new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1).rarity(Rarity.EPIC));
	}
}
