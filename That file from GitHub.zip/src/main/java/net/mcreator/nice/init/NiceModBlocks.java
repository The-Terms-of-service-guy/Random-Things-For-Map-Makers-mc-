
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;

import net.mcreator.nice.block.RubydimentionPortalBlock;
import net.mcreator.nice.block.RubyBlock;
import net.mcreator.nice.block.BucketofmegaBlock;
import net.mcreator.nice.NiceMod;

public class NiceModBlocks {
	public static final DeferredRegister<Block> REGISTRY = DeferredRegister.create(ForgeRegistries.BLOCKS, NiceMod.MODID);
	public static final RegistryObject<Block> RUBY = REGISTRY.register("ruby", () -> new RubyBlock());
	public static final RegistryObject<Block> BUCKETOFMEGA = REGISTRY.register("bucketofmega", () -> new BucketofmegaBlock());
	public static final RegistryObject<Block> RUBYDIMENTION_PORTAL = REGISTRY.register("rubydimention_portal", () -> new RubydimentionPortalBlock());
	// Start of user code block custom blocks
	// End of user code block custom blocks
}
