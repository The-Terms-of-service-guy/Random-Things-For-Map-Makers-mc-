
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.network.chat.Component;
import net.minecraft.core.registries.Registries;

import net.mcreator.nice.NiceMod;

@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD)
public class NiceModTabs {
	public static final DeferredRegister<CreativeModeTab> REGISTRY = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, NiceMod.MODID);
	public static final RegistryObject<CreativeModeTab> MORESTUFFORMAPMAKERS = REGISTRY.register("morestufformapmakers",
			() -> CreativeModeTab.builder().title(Component.translatable("item_group.nice.morestufformapmakers")).icon(() -> new ItemStack(NiceModItems.RUBYITEM.get())).displayItems((parameters, tabData) -> {
				tabData.accept(NiceModItems.BUCKETOFMEGA_BUCKET.get());
			}).withSearchBar().build());

	@SubscribeEvent
	public static void buildTabContentsVanilla(BuildCreativeModeTabContentsEvent tabData) {
		if (tabData.getTabKey() == CreativeModeTabs.COMBAT) {

			tabData.accept(NiceModItems.RUBYARMOR_HELMET.get());
			tabData.accept(NiceModItems.RUBYARMOR_CHESTPLATE.get());
			tabData.accept(NiceModItems.RUBYARMOR_LEGGINGS.get());
			tabData.accept(NiceModItems.RUBYARMOR_BOOTS.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.INGREDIENTS) {

			tabData.accept(NiceModItems.RUBYITEM.get());

		} else if (tabData.getTabKey() == CreativeModeTabs.TOOLS_AND_UTILITIES) {

			tabData.accept(NiceModItems.RUBYDIMENTION.get());

		}
	}
}
