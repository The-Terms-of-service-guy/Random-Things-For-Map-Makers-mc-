
/*
 * MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.api.distmarker.Dist;

import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ItemBlockRenderTypes;

import net.mcreator.nice.fluid.BucketofmegaFluid;
import net.mcreator.nice.NiceMod;

public class NiceModFluids {
	public static final DeferredRegister<Fluid> REGISTRY = DeferredRegister.create(ForgeRegistries.FLUIDS, NiceMod.MODID);
	public static final RegistryObject<FlowingFluid> BUCKETOFMEGA = REGISTRY.register("bucketofmega", () -> new BucketofmegaFluid.Source());
	public static final RegistryObject<FlowingFluid> FLOWING_BUCKETOFMEGA = REGISTRY.register("flowing_bucketofmega", () -> new BucketofmegaFluid.Flowing());

	@Mod.EventBusSubscriber(bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
	public static class FluidsClientSideHandler {
		@SubscribeEvent
		public static void clientSetup(FMLClientSetupEvent event) {
			ItemBlockRenderTypes.setRenderLayer(BUCKETOFMEGA.get(), RenderType.translucent());
			ItemBlockRenderTypes.setRenderLayer(FLOWING_BUCKETOFMEGA.get(), RenderType.translucent());
		}
	}
}
