
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.nice.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.BlockItem;

import net.mcreator.nice.item.RubydimentionItem;
import net.mcreator.nice.item.RubyarmorItem;
import net.mcreator.nice.item.RUBYITEMItem;
import net.mcreator.nice.item.BucketofmegaItem;
import net.mcreator.nice.NiceMod;

public class NiceModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, NiceMod.MODID);
	public static final RegistryObject<Item> RUBYARMOR_HELMET = REGISTRY.register("rubyarmor_helmet", () -> new RubyarmorItem.Helmet());
	public static final RegistryObject<Item> RUBYARMOR_CHESTPLATE = REGISTRY.register("rubyarmor_chestplate", () -> new RubyarmorItem.Chestplate());
	public static final RegistryObject<Item> RUBYARMOR_LEGGINGS = REGISTRY.register("rubyarmor_leggings", () -> new RubyarmorItem.Leggings());
	public static final RegistryObject<Item> RUBYARMOR_BOOTS = REGISTRY.register("rubyarmor_boots", () -> new RubyarmorItem.Boots());
	public static final RegistryObject<Item> RUBY = block(NiceModBlocks.RUBY);
	public static final RegistryObject<Item> RUBYITEM = REGISTRY.register("rubyitem", () -> new RUBYITEMItem());
	public static final RegistryObject<Item> BUCKETOFMEGA_BUCKET = REGISTRY.register("bucketofmega_bucket", () -> new BucketofmegaItem());
	public static final RegistryObject<Item> RUBYDIMENTION = REGISTRY.register("rubydimention", () -> new RubydimentionItem());

	// Start of user code block custom items
	// End of user code block custom items
	private static RegistryObject<Item> block(RegistryObject<Block> block) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), new Item.Properties()));
	}
}
