
package net.mcreator.nice.fluid;

import net.minecraftforge.fluids.ForgeFlowingFluid;

import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.particles.ParticleOptions;

import net.mcreator.nice.init.NiceModItems;
import net.mcreator.nice.init.NiceModFluids;
import net.mcreator.nice.init.NiceModFluidTypes;
import net.mcreator.nice.init.NiceModBlocks;

public abstract class BucketofmegaFluid extends ForgeFlowingFluid {
	public static final ForgeFlowingFluid.Properties PROPERTIES = new ForgeFlowingFluid.Properties(() -> NiceModFluidTypes.BUCKETOFMEGA_TYPE.get(), () -> NiceModFluids.BUCKETOFMEGA.get(), () -> NiceModFluids.FLOWING_BUCKETOFMEGA.get())
			.explosionResistance(100f).slopeFindDistance(9).bucket(() -> NiceModItems.BUCKETOFMEGA_BUCKET.get()).block(() -> (LiquidBlock) NiceModBlocks.BUCKETOFMEGA.get());

	private BucketofmegaFluid() {
		super(PROPERTIES);
	}

	@Override
	public ParticleOptions getDripParticle() {
		return ParticleTypes.BUBBLE;
	}

	public static class Source extends BucketofmegaFluid {
		public int getAmount(FluidState state) {
			return 8;
		}

		public boolean isSource(FluidState state) {
			return true;
		}
	}

	public static class Flowing extends BucketofmegaFluid {
		protected void createFluidStateDefinition(StateDefinition.Builder<Fluid, FluidState> builder) {
			super.createFluidStateDefinition(builder);
			builder.add(LEVEL);
		}

		public int getAmount(FluidState state) {
			return state.getValue(LEVEL);
		}

		public boolean isSource(FluidState state) {
			return false;
		}
	}
}
